                               				 Student Feedback System

Requirements :
	1.Xampp Server 
	2.Web Browser 
Steps :
	First copy this "sfs" folder to c:\xampp\htdocs\ then 

	1.Open Xampp Sever Control Panel
	2.Start Mysql and Apache sever
	3.Open admin of Mysql in any browser then create new database and name it as "sfs" (without double quotes)
	4.Then click on import 
	5.Then import it from here "c:\xampp\htdocs\sfs\database\sfs.sql"
	6.Copy this url in your browser "localhost/sfs/index.php" and hit enter if you want to run it on your own PC (where you have installed xampp)
	7.Now you can access the project.

Admin Login :
	User : admin
	Password : admin
CMHOD : 
	User : cmhod
	Password : cmhod
IFHOD :
	User : ifhod
	Password : ifhod

Short Forms :
	FY : First Year
	SY : Second Year
	TY : Third Year
	CM : Computer Technology (Branch)
	IF : Information Technology  (Branch)

Adding Student :	
	1.Admin and HOD can add students in database
	2.Admin can add students of both department but HOD can add only student respective to thier department
	3.When student is added only username,department and year can be given manually and password is automatically set 		which is same as username.

Created by : Saurabh Narhe 
Contact : 8605469259

