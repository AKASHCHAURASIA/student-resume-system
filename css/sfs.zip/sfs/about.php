<html >
  <head>
    <title>Student Feedback System</title>

    <link rel="stylesheet" href="css/normalize.css">

<style>
body {
  font-family: "Open Sans", sans-serif;
  height: 100vh;
  background: 50% fixed;
  background-size: cover;
}
@keyframes spinner {
  0% {
    transform: rotateZ(0deg);
  }
  100% {
    transform: rotateZ(359deg);
  }
}
* {
  box-sizing: border-box;
}
.wrapper {
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  width: 100%;
  min-height: 100%;
  padding: 20px;
  background: rgba(4, 40, 68, 0.85);
  color:white;
  font-family: Kristen ITC;
  font-size: 14;
}
.title{
  font-family: Kristen ITC;

}
footer {
  display: block;
  padding-top: 50px;
  text-align: center;
  color: #ddd;
  font-weight: normal;
  text-shadow: 0px -1px 0px rgba(0, 0, 0, 0.2);
  font-size: 0.8em;
	position: auto;
	font-family: :Kristen ITC;
}
footer a, footer a:link {
  color: #fff;
	font-family: :Kristen ITC;
	position: auto;
}
</style>
  </head>
<body>
    <div class="wrapper">
    Developers <br><br>
    1.Saurabh Narhe<br>
    2.Ashwini Kharde<br>
    3.Varun Brahmane<br>
    4.Sonali Doifode<br>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<footer>Copyright&copy<?php echo date("Y");?> All copyrights reserved<br>@Saurabh Narhe<br><a href="about.php">About Us</a></footer>
</div>
</body>
</html>
